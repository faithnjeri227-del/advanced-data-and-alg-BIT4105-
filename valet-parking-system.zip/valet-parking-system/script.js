(function(){
  const TOTAL_SPOTS = 60;
  let activeTickets = [];   // {id, spot, name, phone, make, color, plate, rate, inTime}
  let usedSpots = new Set();
  let servedToday = 0;
  let seq = 1;

  const grid = document.getElementById('ticketGrid');
  const statParked = document.getElementById('statParked');
  const statAvail = document.getElementById('statAvail');
  const statToday = document.getElementById('statToday');
  const searchBox = document.getElementById('searchBox');
  const toastEl = document.getElementById('toast');

  function pad(n){ return n.toString().padStart(2,'0'); }

  function updateClock(){
    const d = new Date();
    document.getElementById('clock').textContent =
      d.toLocaleDateString(undefined,{month:'short', day:'numeric'}) + ' · ' +
      pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }
  updateClock();
  setInterval(updateClock, 1000);

  function nextSpot(){
    for(let i=1;i<=TOTAL_SPOTS;i++){
      if(!usedSpots.has(i)) return i;
    }
    return null;
  }

  function ticketId(){
    const now = new Date();
    return 'V-' + (now.getMonth()+1).toString().padStart(2,'0') + now.getDate().toString().padStart(2,'0') + '-' + seq.toString().padStart(3,'0');
  }

  function showToast(msg){
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(()=> toastEl.classList.remove('show'), 2200);
  }

  function fmtElapsed(ms){
    const totalMin = Math.floor(ms/60000);
    const h = Math.floor(totalMin/60);
    const m = totalMin % 60;
    return (h>0? h+'h ':'') + m + 'm';
  }

  function renderStats(){
    statParked.textContent = activeTickets.length;
    statAvail.textContent = TOTAL_SPOTS - activeTickets.length;
    statToday.textContent = servedToday;
  }

  function renderGrid(){
    const q = searchBox.value.trim().toLowerCase();
    const list = activeTickets.filter(t => {
      if(!q) return true;
      return t.name.toLowerCase().includes(q) || t.plate.toLowerCase().includes(q) || t.id.toLowerCase().includes(q);
    });

    grid.innerHTML = '';
    if(list.length === 0){
      const div = document.createElement('div');
      div.className = 'empty-state';
      div.innerHTML = activeTickets.length === 0
        ? '<strong>Garage is clear</strong>Issue a ticket on the left to bring a car onto the floor.'
        : '<strong>No matches</strong>Try a different name, plate, or ticket number.';
      grid.appendChild(div);
      return;
    }

    list.slice().reverse().forEach(t=>{
      const tilt = (Math.random()*1.2 - 0.6).toFixed(2);
      const card = document.createElement('div');
      card.className = 'ticket';
      card.style.setProperty('--tilt', tilt + 'deg');
      card.innerHTML = `
        <div class="t-head">
          <span class="t-id">${t.id}</span>
          <div class="t-spot">${t.spot}<span class="lbl">Spot</span></div>
        </div>
        <div class="perf"></div>
        <div class="t-body">
          <div class="t-name">${t.name}</div>
          <div class="t-car">${t.color} ${t.make}</div>
          <div class="t-plate">${t.plate}</div>
          <div class="t-foot">
            <span>In at ${t.inTime.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'})}</span>
            <span class="t-elapsed" data-in="${t.inTime.getTime()}">${fmtElapsed(Date.now()-t.inTime.getTime())}</span>
          </div>
          <div class="t-actions">
            <button data-id="${t.id}" class="retrieve-btn">Retrieve vehicle</button>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  }

  function tickElapsed(){
    document.querySelectorAll('.t-elapsed').forEach(el=>{
      const inTime = parseInt(el.dataset.in,10);
      el.textContent = fmtElapsed(Date.now()-inTime);
    });
  }
  setInterval(tickElapsed, 15000);

  // ---- Check-in ----
  document.getElementById('checkinForm').addEventListener('submit', function(e){
    e.preventDefault();
    const spot = nextSpot();
    if(spot === null){
      showToast('Garage full — no spots available');
      return;
    }
    const t = {
      id: ticketId(),
      spot,
      name: document.getElementById('cName').value.trim(),
      phone: document.getElementById('cPhone').value.trim(),
      make: document.getElementById('cMake').value.trim(),
      color: document.getElementById('cColor').value.trim(),
      plate: document.getElementById('cPlate').value.trim().toUpperCase(),
      rate: parseFloat(document.getElementById('cRate').value),
      inTime: new Date()
    };
    seq++;
    usedSpots.add(spot);
    activeTickets.push(t);
    renderStats();
    renderGrid();
    showToast('Ticket ' + t.id + ' issued — spot ' + spot);
    e.target.reset();
  });

  // ---- Retrieve / checkout ----
  grid.addEventListener('click', function(e){
    const btn = e.target.closest('.retrieve-btn');
    if(!btn) return;
    const id = btn.dataset.id;
    const idx = activeTickets.findIndex(t=>t.id === id);
    if(idx === -1) return;
    const t = activeTickets[idx];
    const ms = Date.now() - t.inTime.getTime();
    const hours = Math.max(1, Math.ceil(ms/3600000));
    const fee = hours * t.rate;

    activeTickets.splice(idx,1);
    usedSpots.delete(t.spot);
    servedToday++;
    renderStats();
    renderGrid();

    openReceipt(t, hours, fee);
  });

  function openReceipt(t, hours, fee){
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `
      <div class="receipt">
        <h3>Vehicle retrieved</h3>
        <div class="sub">Ticket ${t.id} · Spot ${t.spot}</div>
        <div class="receipt-row"><span>Guest</span><span>${t.name}</span></div>
        <div class="receipt-row"><span>Vehicle</span><span>${t.color} ${t.make}</span></div>
        <div class="receipt-row"><span>Plate</span><span>${t.plate}</span></div>
        <div class="receipt-row"><span>Duration billed</span><span>${hours} hr${hours>1?'s':''}</span></div>
        <div class="receipt-row"><span>Rate</span><span>$${t.rate.toFixed(2)}/hr</span></div>
        <div class="receipt-row total"><span>Total due</span><span>$${fee.toFixed(2)}</span></div>
        <button id="closeReceipt">Close ticket</button>
      </div>
    `;
    document.body.appendChild(overlay);
    overlay.querySelector('#closeReceipt').addEventListener('click', ()=> overlay.remove());
    overlay.addEventListener('click', (e)=>{ if(e.target === overlay) overlay.remove(); });
    showToast('Spot ' + t.spot + ' is now open');
  }

  searchBox.addEventListener('input', renderGrid);
  document.getElementById('clearSearch').addEventListener('click', ()=>{ searchBox.value=''; renderGrid(); });

  renderStats();
  renderGrid();
})();